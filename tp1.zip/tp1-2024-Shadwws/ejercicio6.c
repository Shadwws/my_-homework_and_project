/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Escribir una función que, mediante restas sucesivas
 * obtenga el valor del cociente y el resto de dos números enteros.
 */

int cociente_lento(int dividendo, int divisor);


int resto_lento(int dividendo, int divisor);

int main()
{
    int dividendo;
    int divisor;
    int resto;
    int cociente;

    printf("ingrese el dividendo: ");
    scanf("%d", &dividendo);

    printf("ingrese el divisor: ");
    scanf("%d", &divisor);
    if (divisor !=0)
    {
        resto=resto_lento(dividendo, divisor);
        cociente=cociente_lento(dividendo, divisor);

        printf("la division entre %d y %d da como resultado %d con resto %d", dividendo, divisor, cociente, resto);
    }
    else
    {
        printf("ERROR, no se puede dividir por 0");
    }
    return 0;
}


int resto_lento(int dividendo, int divisor)
{
    int resto;
    
    if (dividendo > 0 && divisor>0)
    {
        while (dividendo>=divisor)
        {
            dividendo=dividendo-divisor;
        }
        resto=dividendo;
    }

    else if(dividendo>0 && divisor<0)
    {
        while (dividendo>=0)
        {
            dividendo=dividendo+divisor;
        }
        resto=dividendo-divisor;
    }

    else if(dividendo<0 && divisor > 0)
    {
        while (dividendo<=0)
        {
            dividendo=dividendo+divisor;
        }
        resto=-(dividendo-divisor);
    }

    else
    {
        while (dividendo<=0)
        {
            dividendo=dividendo-divisor;
        }
        resto=-(dividendo+divisor);
    }
    return resto;
}

int cociente_lento(int dividendo, int divisor)
{
    int cociente=0;
     if (dividendo > 0 && divisor>0)
    {
        while (dividendo>=divisor)
        {
            dividendo=dividendo-divisor;
            cociente++;
        }
    }

    else if(dividendo>0 && divisor<0)
    {
        while (dividendo>=(-divisor))
        {
            dividendo=dividendo+divisor;
            cociente++;
        }
        cociente=(-cociente);
    }

    else if(dividendo<0 && divisor > 0)
    {
        while (dividendo<=(-divisor))
        {
            dividendo=dividendo+divisor;
            cociente++;
        }
        cociente=(-cociente);
    }

    else
    {
        while (dividendo<=divisor)
        {
            dividendo=dividendo-divisor;
            cociente++;
        }
        
    }

    return cociente;
}
