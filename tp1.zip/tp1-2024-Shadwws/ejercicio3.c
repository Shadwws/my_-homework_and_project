/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que reciba un número entero e indique
 * si el mismo es positivo, negativo o cero.
 */

int signo(int numero);


int main()
{
    int numero;
    int resultado;

    printf("ingrese un numero: ");
    scanf("%d", &numero);

    resultado=signo(numero);

    printf("%d \n", resultado);

    return 0;
}

int signo(int numero)
{
    int que_es;
    if (numero<0)
    {
        que_es=-1;
    }

    else if (numero>0)
    {
        que_es=1;
    }

    else
    {
        que_es=0;
    }
    return que_es;
}
