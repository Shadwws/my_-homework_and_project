/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que retorne:
 *
 * Retornar -1 si el primero es menor que el segundo
 * Retornar 0 si son iguales
 * Retornar 1 si el primero es mayor que el segundo
 */

int compara(int numero, int otro_numero);


void main()
{
	int primer=0;
	int segund=0;
	int retorno=0;
	printf("Ingrese el primer numero a comparar: ");
	scanf("%d", &primer);
	printf("Ingrese el segundo numero a comparar: ");
	scanf("%d", &segund);

	retorno=compara(primer, segund);

	printf("El resultado es %d\n", retorno);
}


int compara(int numero, int otro_numero)
{
    int comparado;
    if (numero>otro_numero)
    {
        comparado=1;
    }
    else if (numero<otro_numero)
    {
        comparado=-1;
    }
    else
    {
        comparado=0;
    }
    return comparado;
}
