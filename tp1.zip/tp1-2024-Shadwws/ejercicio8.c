/*
 
* Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que sume los números enteros comprendidos entre dos cotas.
 * Siendo n inclusive y m no inclusive.
 */


int suma_rango(int n, int m);

int main()
{
    int comienzo;
    int final;
    int resultado;
    printf("ingrese el primer numero para la suma en rango *recuerde que empieza desde el mas chico y se hara hasta el mas grande sin incluirse*:  ");//ingreso de los datos
    scanf("%d", &comienzo);

    printf("ingrese el segundo numero:  ");
    scanf("%d", &final);

    resultado=suma_rango(comienzo, final);//llamado de la funcion

    printf("el resultado es: %d\n", resultado);
    return 0;
}

int suma_rango(int n, int m)
{
    int resultado;
    int i;
    if(n>m)//comparo cual es mayor, para saber cual es mas grande
    {
        for(i=m;i<n;i++)//bucle donde sumare todo los numeros entre ambos, sin contar el limite
        {
            resultado=resultado+i;
        }
    }

    else
    {
        for(i=n;i<m;i++)//lo mismo que el anterior
        {
            resultado=resultado+i;
        }
    }
    return resultado;
}
