/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que dado un número entero y un límite
 * retorne el número incrementado en 1 hasta el límite.
 */

int contador_circular(int i, int limite);

int main()
{
    int j;
    int retorno;
    int i;
    int limite;
    int cuantas_veces;

    printf("ingrese el valor inicial: ");//zona de carga de datos
    scanf("%d", &i);
    printf("ingrese el valor limite: ");
    scanf("%d", &limite);

    printf("cuantas vueltas desea hacerlo");
    scanf("%d", &cuantas_veces);//pedimos cuantas veces quiere que se imprima la funcion

    for(j=0; j!=cuantas_veces; j++)
    {
        retorno=contador_circular(i,limite);//llamamos la funcion
        printf("%d \n", retorno);
    }
}


int contador_circular(int i, int limite)
{
    {
        while(i<limite)//bucle que imprime el valor del numero inicial + 1, hasta que el valor inicial sea igual a limite
        {
            printf("%d \n", i);
            i++;
        }
    }
    i=0;//una vez el valor inicial sea igual al limite, retorna 0, para mostrarse
    return i;
}
