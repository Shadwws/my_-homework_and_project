/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que obtenga, de manera aritmética, la suma de los dígitos de un número entero.
 */

int suma_digitos(int numero);

int main()
{
   
}

int suma_digitos(int numero)
{
   
}

