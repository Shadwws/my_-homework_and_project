/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Copien el enunciado aquí.
 */


int main()
{
   //COMPLETAR
}
