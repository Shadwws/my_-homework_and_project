/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */
#include <stdio.h>
#include <stdbool.h>

/*
 * Escribir una función que retorne true si un número entero indicado es Primo y false cuando no lo sea.
 * La obtención de este resultado debe ser mediante divisiones sucesivas.
 */

bool es_primo(int numero);

int main()
{
    bool resultado;
    int numero1 ;
    printf("Ingrese un numero: ");
    scanf("%d", &numero1);


    resultado=es_primo(numero1);
    printf("%d", resultado);

    return 0;
}






bool es_primo(int numero)
{
    int resultado=0;
    int i=numero;
    int divisibles=0;
    bool salida;
    while(i>0)
    {
        resultado=numero%i;
	i--;
        if(resultado==0)
        {
            divisibles = divisibles + 1;
        }
    }
    if(divisibles > 2)
    {
        salida=false;
    }

    else
    {
        salida=true;
    }
    return salida;

}
