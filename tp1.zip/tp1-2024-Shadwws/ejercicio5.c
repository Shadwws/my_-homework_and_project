/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que haga la suma entre dos números enteros sin hacer
 * la operación de manera directa. 
 * Esto quiere decir que para hacer la suma entre 4 y 3, las operaciones resultantes deberán ser 4+1+1+1.
 * La función debe ser capaz de sumar cualquier número entero, positivo y negativo.
 */

int suma_lenta(int sumando, int sumador);

void main()
{
    int sumando=0;
    int sumador=0;
    int resultado=0;

    printf("ingrese el primer numero: ");
    scanf("%d", &sumando);

    printf("ingrese el segundo numero: ");
    scanf("%d", &sumador);

    resultado=suma_lenta(sumando, sumador);

    printf("%d", resultado);

}

int suma_lenta(int sumando, int sumador)
{
	if (sumador>0)
	{
		while (sumador>0)
		{
			sumando=sumando+1;
			sumador=sumador-1;
		}
	}

	else
	{
		while(sumador<0)
                {
                        sumando=sumando-1;
			sumador=sumador+1;
                }

	}

	return sumando;
}

