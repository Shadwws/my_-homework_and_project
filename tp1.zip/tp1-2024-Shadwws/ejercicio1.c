/*
 * Martín Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
*Desarrollar un programa que muestre por STDOUT el mensaje "Hola Mundo C!".
*Indicar en un comentario la instrucción de compilación con GCC por línea de comandos.
*/


int main()
{
	printf("Hola Mundo C!");

	return 1;
}
