/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>
#include <stdbool.h>


/*
 * Escribir una función que retorne true si un número
 * entero es múltiplo de otro, utilizando sumas y restas.
 */

bool es_multiplo(int numero, int multiplo);

int main()
{
    int numero;
    int multiplo;
    bool retorno;
    printf("Ingrese un numero: ");
    scanf("%d", &numero);

    printf("ingrese el otro numero: ");
    scanf("%d", &multiplo);

    retorno=es_multiplo(numero, multiplo);

    printf("%d\n", retorno);

    return 0;
}


bool es_multiplo(int numero, int multiplo)
{
    bool resultado=false;
    if (numero>0 && multiplo>0)
    {
        while(numero<=multiplo)
        {
            multiplo=multiplo-numero;
            if(numero == multiplo)
            {
                resultado=1;
            }
        }
    }

    else if (numero<0 && multiplo<0)
    {
        while(numero>=multiplo)
        {
            multiplo=multiplo-numero;
            if (multiplo==numero)
            {
                resultado=true;
            }
        }

    }

    else if (numero>0 && multiplo<0)
    {
        multiplo=-(multiplo);//en el caso que sean 2 signos distintos, primero cambiamos el signo de uno para mas facilidad de manipulacion
        while(numero<=multiplo)
        {
            multiplo=multiplo-numero;//se hace lo mismo que los anteriores
            if(numero == multiplo)
            {
                resultado=true;
            }
        }
    }

    else
    {
        numero=-(numero);
        while(numero<=multiplo)
        {
            multiplo=multiplo-numero;
            if (multiplo==numero)
            {
                resultado=true;
            }
        }
    }
    return resultado;
}
