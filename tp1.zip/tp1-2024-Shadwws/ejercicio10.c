/*
 * Martin Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Implementar una función que, usando lazos, permita obtener el factorial de un número entero positivo.
 */

long factorial(int numero);

int main()
{
    int numero;
    long resultado;
    printf("ingrese el numero a realizarle factorial: ");
    scanf("%d", &numero);

    if(numero>0)
    {
        resultado= factorial(numero);
        printf("el resultado es %ld\n", resultado);
    }
    else
    {
        printf("ERROR, solo se acepta numeros entero positivos\n");
    }
    return 0;

}

long factorial(int numero)
{
    int i;
    long resultado=1;
    for (i=1; i<numero+1; i++)
    {
        resultado=resultado*i;
    }
    return resultado;
}
