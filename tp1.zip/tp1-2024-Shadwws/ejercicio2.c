/*
 * Martín Aburto
 * Comision 3 - 2024
 * Programacion 1 - Ingenieria en Computacion
 */

#include <stdio.h>

/*
 * Se quiere transformar temperaturas en grados Fahrenheit a grados centígrados y viceversa.
 * Implementar las funciones para convertir la temperatura en grados centígrados en Fahrenheit como un número decimal
 * utilice esta fórmula para calcular los grados centígrados y retorne el resultado obtenido. Y viceversa.
 */

double centigrados_a_fahrenheit(double centigrados);
double fahrenheit_a_centigrados(double fahrenheit);

void main()
{
	int seleccion = 0;
	double numero_convertido= 0.0;
	double numero_convertir = 0.0;
	printf("1-Para pasar centigrados a fahrenheit\n2-Para pasar de fahrenheit a centigrados\n Ingrese :");
	scanf("%d", &seleccion);

	printf("Ingrese el numero a convertir: ");
	scanf("%lf", &numero_convertir);

	if (seleccion==1)
	{
		numero_convertido=centigrados_a_fahrenheit(numero_convertir);
		printf("%lf centigrados son %lf fahrenheit \n", numero_convertir, numero_convertido);
	}
	else if(seleccion==2)
	{
		numero_convertido=fahrenheit_a_centigrados(numero_convertir);
		printf("%lf fahrenheit son %lf centigrados\n",numero_convertir, numero_convertido);
	}
	else
	{
		printf("Error, intente de nuevo\n");
	}

	printf("Gracias por usar el programa \n");
}


double centigrados_a_fahrenheit(double centigrados)
{
	double resultado_fahrenheit;
	resultado_fahrenheit = (centigrados * 9/5) + 32;
	return resultado_fahrenheit;
}
double fahrenheit_a_centigrados(double fahrenheit)
{
	double resultado_centigrados;
        resultado_centigrados = (fahrenheit-32)*5/9;


        return resultado_centigrados;

}
